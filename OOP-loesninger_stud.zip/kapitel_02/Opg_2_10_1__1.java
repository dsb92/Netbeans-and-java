public class Opg_2_10_1__1
{
	public static void main(String[] args)
	{
		for (int x=25; x<=75; x++)
		{
			double bel�b = (x-25)*1.54;
			System.out.println("For " + x + " km er fradraget " + bel�b + " kr.");
		}
	}
}
