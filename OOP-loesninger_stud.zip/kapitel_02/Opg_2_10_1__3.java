public class Opg_2_10_1__3
{
	public static void main(String[] args)
	{
		for (int x=10; x<=150; x=x+10)
		{
			double bel�b = 0;

			if (x>100) bel�b = (x-100)*0.77+(100-25)*1.54;
			else if (x>25) bel�b = (x-25)*1.54;

			System.out.println("For " + x + " km er fradraget " + bel�b + " kr.");
		}
	}
}
