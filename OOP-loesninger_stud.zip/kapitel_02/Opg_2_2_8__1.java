public class Opg_2_2_8__1
{
  public static void main(String[] args)
  {
    int l�ngde, bredde, areal;

    l�ngde = 3;
    bredde = 2;
    System.out.println("L�ngde er: "+l�ngde);
    System.out.println("Bredden er: "+bredde);

    areal = l�ngde * bredde;
    System.out.println("S� er arealet: "+areal);
  }
}
