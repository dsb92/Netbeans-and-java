public class Opg_2_2_8__3
{
  public static void main(String[] args)
  {
    double dollar, euro;

    dollar = 10;
    double kurs = 95;

    euro = dollar * kurs / 100;


    System.out.println(dollar+" dollar svarer til "+euro+" euro");
  }
}
