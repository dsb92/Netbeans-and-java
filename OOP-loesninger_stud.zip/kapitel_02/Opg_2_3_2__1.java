import javax.swing.*;

public class Opg_2_3_2__1
{
  public static void main(String[] args)
  {
    double dollar, euro, kurs;

    kurs = 95;
    dollar = 10;

    // Lav et vindue der sp�rger brugeren om bel�bet
    dollar = Double.parseDouble(
      JOptionPane.showInputDialog("Indtast bel�b i dollar.")
    );
    
    euro = dollar * kurs / 100;

    double kommision = euro * 0.02;
    if (kommision<0.5) {
      euro = euro - 0.5;
    } else {
      euro = euro - kommision;
    }
    System.out.println("Bel�bet i euro er " + euro);
    System.out.println("Kommisionen er " + kommision);
  }
}
