public class Opg_2_3_2__3
{
  public static void main(String[] args)
  {
    double tal1, tal2, tal3;
	tal1 = Math.random();
    System.out.println("Tal1: "+tal1);
	
	tal2 = Math.random();
    System.out.println("Tal2: "+tal2);
	
	tal3 = Math.random();
    System.out.println("Tal3: "+tal3);

	if (tal1 > tal2 && tal1 > tal3) System.out.println("Tal1 er st�rst");
	else if (tal2 > tal3) System.out.println("Tal2 er st�rst");
	else System.out.println("Tal3 er st�rst");

	if (tal1 < tal2 && tal1 < tal3) System.out.println("Tal1 er mindst");
	else if (tal2 < tal3) System.out.println("Tal2 er mindst");
	else System.out.println("Tal3 er mindst");
  }
}
