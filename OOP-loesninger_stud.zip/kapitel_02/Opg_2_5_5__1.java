public class Opg_2_5_5__1
{
	public static void main(String[] args) 
	{
		for (int x=10; x>=1; x--)
		{
			System.out.println("x er " + x);
		}
	}
}
