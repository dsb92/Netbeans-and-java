public class Opg_3_4_6__1
{
	public static void main(String[] args)
	{
		String s="Hej alle sammen";
		int i=0;
		i=s.indexOf(" ");
		if (i==-1) {
			System.out.println("Der er ingen mellemrum i linien");
		} else {
			System.out.println("Mellemrummet er p� plads : " + i);
		}
	}
}
