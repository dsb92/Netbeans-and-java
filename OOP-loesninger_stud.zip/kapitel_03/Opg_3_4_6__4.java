public class Opg_3_4_6__4{
	public static void main(String[] args)
	{
		String s="m�skeHej m�ske alle m�ske sammen m�ske";
		String s2="m�ske";

		int i = s.indexOf(s2);

		while (i!=-1) {
			String f�r,efter;

			efter=s.substring(i+5);
			f�r=s.substring(0,i);
			s=f�r+efter;

			System.out.println(s);

			i=s.indexOf(s2);
		}
	}
}
