import java.util.*;
import java.io.*;

public class Opg_3_6_3__3
{
	public static void main(String[] args) throws Exception
	{
		Date netopNu = new Date();

		int dag, m�ned, �r;

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		System.out.print("Indtast f�dsels�r: ");
		�r = Integer.parseInt(br.readLine());

		System.out.print("Indtast f�dselsm�ned: ");
		m�ned = Integer.parseInt(br.readLine());

		System.out.print("Indtast f�dselsdag: ");
		dag = Integer.parseInt(br.readLine());

		Date f�dselsdage = new Date(�r, m�ned-1, dag);

		while (f�dselsdage.getYear()<netopNu.getYear()) {
			System.out.println("F�dselsdagen er : " + f�dselsdage);
			f�dselsdage.setYear(f�dselsdage.getYear()+1);
		}

	}
}
