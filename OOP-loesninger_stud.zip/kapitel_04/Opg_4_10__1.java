class Bil
{
	public int pris;
	public String farve;
	public String m�rke;
	public int kilometer;

	public Bil(String m�rket, String farven, int kilometerne, int prisen)
	{
		pris = prisen;
		farve = farven;
		m�rke = m�rket;
		kilometer = kilometerne;
	}

	public String toString()
	{
		return "m�rke:"+m�rke+" farve:"+farve+" kilometer:"+kilometer+" pris:"+pris;
	}

	public int pris()
	{
		return pris;
	}

	public void k�r(int km)
	{
		pris = pris - km/2;
	}

	public void vis()
	{
		System.out.println("M�rke : "+m�rke);
		System.out.println("Farve : "+farve);
		System.out.println("Pris : "+pris);
		System.out.println("Kilometer : "+kilometer);
	}
}

public class Opg_4_10__1
{
	static public void main(String[] args)
	{
		Bil b;
		b = new Bil("Volvo", "Bl�", 20000, 200000);

		b.vis();

		System.out.println("Bilen "+b+" k�rer 500 kilometer.");
		b.k�r(500);
		System.out.println("Den er nu kun "+b.pris()+" kroner v�rd.");
		b.vis();
	}
}
