class Pyramide
{
    private double side;
    private double h�jde;

    public Pyramide()
    {
        System.out.println("Standardpyramide oprettes");
        side=10;
        h�jde=10;
    }

    public Pyramide(double s, double h)
    {
        if (s<=0 || h<=0)
        {
            System.out.println("Ugyldige m�l. Standardpyramide oprettes");
            side=10;
            h�jde=10;
        } else
        {
            side=s;
            h�jde=h;
        }
    }

    public double volumen()
    {
        return side*side*h�jde/4;
    }
}


public class Opg_4_3_2__1
{
    static public void main(String[] args)
    {
        Pyramide pyramide1 = new Pyramide();
        Pyramide pyramide2 = new Pyramide(-2.1, 0);
        Pyramide pyramide3 = new Pyramide(4, 3);

        System.out.println("Pyramide1 har rumfanget : " + pyramide1.volumen());
        System.out.println("Pyramide2 har rumfanget : " + pyramide2.volumen());
        System.out.println("Pyramide3 har rumfanget : " + pyramide3.volumen());
    }
}
