public class Opg_4_5_2__1
{
	static public void main(String[] args)
	{

		Raflebaeger b�ger1 = new Raflebaeger(4);
		int antalSlag = 0;
		while(b�ger1.antalDerViser(6) != 3 && b�ger1.antalDerViser(6) != 4)
		{
			antalSlag++;
			b�ger1.ryst();
			System.out.println("Slag nr. " + antalSlag);
			System.out.println(b�ger1.toString());
		}
		System.out.println("Slag nr. " + antalSlag);
	}
}
