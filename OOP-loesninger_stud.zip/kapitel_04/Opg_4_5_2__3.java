import java.util.*;

class Rafleb�ger
{
	public Vector terninger;  // Raflebaeger har en vektor af terninger

	public Rafleb�ger(int antalTerninger)
	{
		terninger = new Vector();
		for (int i=0;i<antalTerninger;i++)
		{
			Terning t;
			t = new Terning();
			tilf�j(t);
		}
	}

	public void tilf�j(Terning t)       // L�g en terning i b�geret
	{
		terninger.addElement(t);
	}

	public void ryst()                  // Kast alle terningerne
	{
		for (int i=0;i<terninger.size();i++)
		{
			Terning t;
			t = (Terning) terninger.elementAt(i);
			t.kast();
		}
	}

	public int sum()                    // Summen af alle terningers v�rdier
	{
		int resultat;
		resultat=0;
		for (int i=0;i<terninger.size();i++)
		{
			Terning t;
			t = (Terning) terninger.elementAt(i);
			resultat = resultat + t.v�rdi;
		}
		return resultat;
	}

	public int antalDerViser(int v�rdi) // Antal terninger med en bestemt v�rdi
	{
		int resultat;
		resultat = 0;
		for (int i=0;i<terninger.size();i++)
		{
			Terning t;
			t = (Terning) terninger.elementAt(i);
			if (t.v�rdi==v�rdi)
			{
				resultat = resultat + 1;
			}
		}
		return resultat;
	}

	public boolean femEns()
	{
		return nEns(5);
	}

	public boolean fireEns()
	{
		return nEns(4);
	}

	public boolean treEns()
	{
		return nEns(3);
	}

	public boolean toEns()
	{
		return nEns(3);
	}

	public boolean etPar()
	{
		return nEns(3);
	}

	public boolean nEns(int antalEns)
	{
		for (int v�rdi=1; v�rdi<=6; v�rdi++)
		{
			if (antalDerViser(v�rdi) == antalEns) return true;
		}
		return false;
	}

	public boolean hus()
	{
		return toEns() && treEns();
	}

	public boolean toPar()
	{
		int antalPar = 0;
		for (int v�rdi=1; v�rdi<=6; v�rdi++)
		{
			if (antalDerViser(v�rdi) == 2) antalPar++;
		}
		return antalPar==2;
	}

	public boolean storStraight()
	{
		for (int v�rdi=2; v�rdi<=6; v�rdi++)
		{
			if (antalDerViser(v�rdi) != 1) return false;
		}
		return true;
	}

	public boolean lilleStraight()
	{
		for (int v�rdi=1; v�rdi<=5; v�rdi++)
		{
			if (antalDerViser(v�rdi) != 1) return false;
		}
		return true;
	}

	public String beskrivelse()
	{
		if (femEns()) return "Fem ens";
		if (fireEns()) return"Fire ens";
		if (storStraight()) return"Stor straight";
		if (lilleStraight()) return"Lille straight";
		if (hus()) return"Hus";
		if (treEns()) return"Tre ens";
		if (toPar()) return"To par";
		if (etPar()) return"Et par";
		return "Ingenting";
	}

	public String toString()
	{
		return terninger.toString() + " " + beskrivelse();
	}
}


public class Opg_4_5_2__3
{
	static public void main(String[] args) {

		Rafleb�ger b�ger1 = new Rafleb�ger(5);
		int antalSlag = 0;
		while(antalSlag < 10)
		{
			antalSlag++;
			b�ger1.ryst();
			System.out.println("Slag nr. " + antalSlag);
			System.out.println("Summen af �jnene var " + b�ger1.sum());
			System.out.println(b�ger1.toString());
			System.out.println();
		}
	}
}
