class LudoTerning extends Terning
{
    public String toString()
    {
        if (v�rdi == 3) return "*";
        if (v�rdi == 4) return "Globus";
        String svar = ""+v�rdi;
        return svar;
    }
}


public class Opg_5_1_4__1
{
    public static void main(String[] args)
    {
        LudoTerning lt = new LudoTerning();
        for (int i = 0; i < 10; i++)
        {
            System.out.println(""+lt);
            lt.kast();
        }
    }
}
