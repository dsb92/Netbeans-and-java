// Matadorspil for to spillere
import java.util.*;


class Bryggeri extends Felt
{
	Spiller ejer;
	double pris;
	double grundleje;

	public Bryggeri(String navn, double pris)
	{
		this.navn = navn;
		this.pris = pris;
	}

	public void landet(Spiller sp)
	{
		System.out.println(sp.navn+" er landet p� "+navn);
		if (sp==ejer)
		{                                       // spiller ejer selv grunden
			System.out.println("Dette er "+sp.navn+"s egen grund");
		}
		else if (ejer==null)
		{                                       // ingen ejer grunden, s� k�b den
			if (sp.konto > pris)
			{
				System.out.println(sp.navn+" k�ber "+navn+" for "+pris);
				ejer=sp;
				sp.transaktion( -pris );
			}
			else System.out.println(sp.navn+" har ikke penge nok til at k�be "+navn);
		}
		else
		{                                       // feltet ejes af anden spiller
			grundleje = 800*((int) (Math.random()*6+1));
                        System.out.println("Husleje: "+grundleje);
			sp.betal(ejer, grundleje);            // spiller betaler til ejeren
		}
	}
}


public class Opg_5_3_2__1
{
	public static void main(String[] args)
	{
		Spiller sp1=new Spiller("S�ren",50000);   // opret spiller 1
		Spiller sp2=new Spiller("Gitte",50000);   // opret spiller 2

		Vector felter=new Vector();               // indeholder alle felter
		felter.addElement(new Start(5000));
		felter.addElement(new Gade("Gade 1",10000, 400,1000));
		felter.addElement(new Gade("Gade 2",10000, 400,1000));
		felter.addElement(new Gade("Gade 3",12000, 500,1200));
		felter.addElement(new Rederi("Maersk",17000,4200));
		felter.addElement(new Gade("Gade 5",15000, 700,1500));
		felter.addElement(new Helle(15000));
		felter.addElement(new Gade("Gade 7",20000,1100,2000));
		felter.addElement(new Gade("Gade 8",20000,1100,2000));
                felter.addElement(new Bryggeri("Tuborg",16000));
		felter.addElement(new Gade("Gade 9",30000,1500,2200));

		// l�b igennem 20 runder
		for (int runde = 0; runde<40; runde=runde+1)
		{
			sp1.tur(felter);
			sp2.tur(felter);
		}
	}
}

