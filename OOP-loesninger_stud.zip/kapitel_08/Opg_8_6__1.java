public class Opg_8_6__1
{
	public static void main(String[] args)
	{
		Raflebaeger b�ger = new Raflebaeger(6);

		int[] hyp = new int[37]; // indgangene 6 til 36 bruges.

		for (int antalSlag = 0; antalSlag<100; antalSlag++)
		{
			b�ger.ryst();
			hyp[ b�ger.sum() ] ++;
		}

		for (int v=6; v<=36; v++)
			System.out.println("Antal slag med "+v+" �jne : " + hyp[v]);
	}
}
