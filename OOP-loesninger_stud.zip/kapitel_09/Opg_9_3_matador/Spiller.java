import java.awt.*;
/**
 * Definition af en spiller
 */
import java.util.*;

public class Spiller
{
	String navn;
	double konto;
	int feltnr;
	Color farve;

	public Spiller(String navn, double konto, Color farve)
	{
		this.navn=navn;
		this.konto=konto;
		this.farve=farve;
		feltnr = 0;
	}

	public void transaktion(double kr)
	{
		konto = konto + kr;
	}

	public void betal(Spiller modtager, double kr)
	{
		System.out.println(navn+" betaler "+modtager.navn+": "+kr+" kr.");
		modtager.transaktion(kr);
		transaktion(-kr);
	}

	public void tur(Vector felter)
	{
		int slag=(int)(Math.random()*6)+1;           // terningkast

		System.out.println("***** "+navn+" der st�r p� felt nr. "+feltnr+" har sl�et "+slag+" *****");

		// nu rykkes der
		for (int i=1;i<=slag;i=i+1)
		{
			// g� til n�ste felt: t�l op, hvis vi n�r over antallet af felter s� t�l fra 0
			feltnr = (feltnr + 1) % felter.size();
			Felt felt;
			felt = (Felt) felter.elementAt(feltnr);
			if (i<slag) felt.passeret(this);              // kald passer() p� felter vi passerer
			else felt.landet(this);                       // kald land() p� sidste felt
		}
		try {Thread.sleep(1000);} catch (Exception e) {}  // vent 3 sek.
	}
}
