import java.applet.*;
import java.awt.*;
import java.util.*;


class Hus implements Tegnbar
{
	int h�jde;
        int bredde;
        int x;
        int y;

        public Hus(int x1, int y1, int width1, int height1)
	{
		x = x1;
                y = y1;
                h�jde = height1;
                bredde = width1;
	}

	public void s�tPosition(int x1, int y1)
	{
		x = x1;
		y = y1;
	}

	public void tegn(Graphics g)
	{
		g.drawRect(x, (int) (y+h�jde/3), bredde, (int) (h�jde*2/3));
                g.drawLine(x, (int) (y+h�jde/3), (int) (x+bredde/3), y);
                g.drawLine((int) (x+bredde/3), y, (int) (x+bredde*2/3), y);
                g.drawLine((int) (x+bredde*2/3), y, x+bredde, (int) (y+h�jde/3));
	}
}



public class Opg_12_6__1 extends Applet
{
	Vector tegnbare = new Vector();
	GrafiskRaflebaeger b�ger = new GrafiskRaflebaeger();

	public void paint(Graphics g)
	{
		super.paint(g);
		for (int n=0; n<tegnbare.size(); n++) {
			Tegnbar t = (Tegnbar) tegnbare.elementAt(n);
			t.tegn(g);
		}
	}

	public void s�tPositioner()
	{
		for (int n=0; n<tegnbare.size(); n++) {
			Tegnbar t = (Tegnbar) tegnbare.elementAt(n);
			int x = (int) (Math.random()*200);
			int y = (int) (Math.random()*200);
			t.s�tPosition(x,y);
		}
	}

	public void init() {
		Stjerne s = new Stjerne();
		tegnbare.addElement(s);

		tegnbare.addElement( new Rektangel(10,10,30,30) );

		tegnbare.addElement( new Rektangel(15,15,20,20) );

		GrafiskTerning t;

		t = new GrafiskTerning();
		b�ger.tilf�j(t);
		tegnbare.addElement(t);

		t = new GrafiskTerning();
		b�ger.tilf�j(t);
		tegnbare.addElement(t);

		tegnbare.addElement(b�ger);

                Hus h = new Hus(0, 0, 50, 30);

                tegnbare.addElement(h);

		s�tPositioner();

		// mere kode her
		// ...
	}

	// flere metoder her
	// ...
}
