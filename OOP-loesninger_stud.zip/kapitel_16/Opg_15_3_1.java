/*
1. L�s Javadokumentationen for klasserne URL og URLConnection, og omskriv HentHjemmeside
	 til at bruge disse klasser i stedet for selv af lave Socket-forbindelser.
*/

import java.io.*;
import java.net.*;
public class Opg_15_3_1
{
	public static void main(String arg[])
	{
		try {
			URL url = new URL("http://esperanto.dk");
			URLConnection forb = url.openConnection();
			InputStream  tilOs = forb.getInputStream();
			BufferedReader ind = new BufferedReader(new InputStreamReader(tilOs));
			String s = ind.readLine();
			while (s != null)        // readLine() giver null n�r datastr�mmen lukkes
			{
				System.out.println("svar: "+s);
				s = ind.readLine();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
