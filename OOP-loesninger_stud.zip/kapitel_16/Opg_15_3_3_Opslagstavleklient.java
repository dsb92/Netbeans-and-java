/*
3. Lav en virtuel opslagstavle. Den skal best� af klasserne Opslagstavletjeneste, som udbyder
	 tjenesten (brug port 8002), og Opslagstavleklient, som forbinder sig til tjenesten.
	 Opslagstavletjeneste skal underst�tte to former for anmodninger: 1) TILF�J, der f�jer en besked
	 til opslagstavlen og 2) HENTALLE, der sender alle opslag til klienten. Afpr�v begge slags
	 anmodninger fra Opslagstavleklient.
*/
import java.io.*;
import java.util.*;
import java.net.*;
public class Opg_15_3_3_Opslagstavleklient
{
	public static void main(String arg[])
	{
		Tastatur t = new Tastatur();
		String lin;
		System.out.print("V�lg: 1) tilf�j   eller   2) hent alle  > ");
		if (t.l�sTal() == 1) lin = "TILF�J"; else lin = "HENTALLE";

		try {
			Socket forbindelse = new Socket("localhost",8002);
			PrintWriter    ud  = new PrintWriter(forbindelse.getOutputStream());
			BufferedReader ind = new BufferedReader(new InputStreamReader(forbindelse.getInputStream()));

			ud.println(lin);
			if (lin.equalsIgnoreCase("TILF�J"))
			{
				System.out.println("OK, skriv teksten og afslut med en blank linie");
				while ((lin = t.l�sLinie()).length()>0) ud.println(lin);
			}
			ud.flush();

			while ((lin = ind.readLine()) != null) System.out.println(lin);
			forbindelse.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
