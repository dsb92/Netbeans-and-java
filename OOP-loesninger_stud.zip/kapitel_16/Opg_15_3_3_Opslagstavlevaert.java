/*
3. Lav en virtuel opslagstavle. Den skal best� af klasserne Opslagstavletjeneste, som udbyder
	 tjenesten (brug port 8002), og Opslagstavleklient, som forbinder sig til tjenesten.
	 Opslagstavletjeneste skal underst�tte to former for anmodninger: 1) TILF�J, der f�jer en besked
	 til opslagstavlen og 2) HENTALLE, der sender alle opslag til klienten. Afpr�v begge slags
	 anmodninger fra Opslagstavleklient.
*/
import java.io.*;
import java.util.*;
import java.net.*;
public class Opg_15_3_3_Opslagstavlevaert
{
	public static void main(String arg[])
	{
		Vector tavle = new Vector();
		try {
			ServerSocket v�rtssokkel = new ServerSocket(8002);
			while (true)
			{
				Socket forb = v�rtssokkel.accept();
				PrintWriter ud = new PrintWriter(forb.getOutputStream());
				BufferedReader ind = new BufferedReader(new InputStreamReader(forb.getInputStream()));

				String lin = ind.readLine();
				System.out.println("Kommando: "+lin);

				if (lin.equalsIgnoreCase("TILF�J"))
				{
					tavle.addElement("--------- "+new Date());
					while ((lin = ind.readLine()) != null) tavle.addElement(lin);
					ud.println("Antal linier p� tablen nu : "+tavle.size());
					System.out.println("Tavle: "+tavle);
				}
				else if (lin.equalsIgnoreCase("HENTALLE"))
				{
					for (int i=0; i<tavle.size(); i++) ud.println((String) tavle.elementAt(i));
					System.out.println("Tavle: "+tavle);
				}
				else
				{
					ud.println("Ukendt kommando: "+lin);
				}

				ud.flush();
				forb.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}