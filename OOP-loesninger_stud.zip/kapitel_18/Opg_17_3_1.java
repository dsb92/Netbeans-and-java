/*
1. Lav et program, der holder styr p� en musiksamling. Opret en klasse, der repr�senterer en
	 udgivelse (int �r, String navn, String gruppe, String pladeselskab). Programmet skal huske
	 listen over udgivelser og kunne udskrive den, brugeren skal kunne tilf�je flere, og gemme og
	 hente listen i en fil (vha. serialisering).
*/
import java.util.*;

public class Opg_17_3_1
{
	public static void main(String arg[]) throws Exception
	{
		Vector samling;
		try
		{
			samling = (Vector) Serialisering.hent("samling.ser");
			System.out.println("Indl�st : " + samling);
		}
		catch (Exception e)
		{
			samling = new Vector();
			samling.addElement(new Udgivelse(1996, "Load", "Metalica", "PolyGram"));
			samling.addElement(new Udgivelse(1992, "Ten", "Pearl Jam", "Sony"));
			samling.addElement(new Udgivelse(1998, "Adore", "Smashing Pumpkins", "Virgin"));
			System.out.println("Oprettet : "+samling);
		}

		Tastatur t = new Tastatur();
		System.out.println("Indtast ny udgivelse: �r, navn, gruppe og pladeselskab (hver p� en ny linie)");

		Udgivelse u = new Udgivelse((int)t.l�sTal(),t.l�sLinie(),t.l�sLinie(),t.l�sLinie());

		samling.addElement(u);

		System.out.println("Den nye samling er :\n "+samling);
		Serialisering.gem(samling, "samling.ser");
	}
}
