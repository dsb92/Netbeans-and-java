import java.applet.*;
import java.awt.*;
import java.util.*;

/**
1. Tag TegnbareObjekter.java fra kapitel 11 og lav (i init()-metoden) fem forskellige objekter, der
	 implementerer Tegnbar-interfacet (brug anonyme klasser). De fem objekter skal have forskellig
	 m�de at reagere p� tegn() og s�tPosition().
 */
public class Opg_21_5_1 extends Applet
{
	Vector tegnbare = new Vector();
	GrafiskRaflebaeger b�ger = new GrafiskRaflebaeger();

	public void paint(Graphics g)
	{
		super.paint(g);
		for (int n=0; n<tegnbare.size(); n++) {
			Tegnbar t = (Tegnbar) tegnbare.elementAt(n);
			t.tegn(g);
		}
	}

	public void s�tPositioner()
	{
		for (int n=0; n<tegnbare.size(); n++) {
			Tegnbar t = (Tegnbar) tegnbare.elementAt(n);
			int x = (int) (Math.random()*200);
			int y = (int) (Math.random()*200);
			t.s�tPosition(x,y);
		}
	}

	public void init() {

		Tegnbar s = new Tegnbar()
		{
			private int posX, posY;

			public void s�tPosition(int x, int y)	// kr�ves af Tegnbar
			{
				posX = x;
				posY = y;
			}

			public void tegn(Graphics g)					// kr�ves af Tegnbar
			{
				g.drawString("*",posX,posY);
			}
		};
		tegnbare.addElement(s);


		s = new Tegnbar()
		{
			private int pos;

			public void s�tPosition(int x, int y)	// kr�ves af Tegnbar
			{
				pos = x + y;
			}

			public void tegn(Graphics g)					// kr�ves af Tegnbar
			{
				g.drawString("+",pos,pos);
			}
		};
		tegnbare.addElement(s);



		tegnbare.addElement( new Tegnbar() {
			private int pos;

			public void s�tPosition(int x, int y)	// kr�ves af Tegnbar
			{
				pos = x / y;
			}

			public void tegn(Graphics g)					// kr�ves af Tegnbar
			{
				g.drawString("/",pos,pos);
			}
		} );


		s�tPositioner();
	}
}