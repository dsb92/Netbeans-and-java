package kapitel_02;
public class Alder
{
	public static void main(String[] arg) 
	{
		int alder;
		alder = 15;

		if (alder >= 18) System.out.println("Du er myndig.");

		System.out.println("Du er " + alder + " år.");
	}
}