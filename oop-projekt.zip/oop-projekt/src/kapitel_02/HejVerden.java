package kapitel_02;
// Et simpelt program, der skriver "Hej verden" 
// og et citat af Storm P. ud til skærmen
// Denne fil skal have navnet: HejVerden.java
public class HejVerden
{
	public static void main (String[] arg)
	{
		System.out.println("Hej Verden!");
		System.out.println("Hvornår smager en Tuborg bedst?");
		System.out.println("Hvergang!");
	}
}