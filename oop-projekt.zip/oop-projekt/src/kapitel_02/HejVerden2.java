package kapitel_02;
// Sammensæt to strenge med +
// koden skal være i filen HejVerden2.java
public class HejVerden2
{
	public static void main (String[] arg)
	{
		System.out.println("Hej " + "Verden!");
	}
}