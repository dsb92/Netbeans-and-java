package kapitel_02;
public class HejVerden3
{
	public static void main (String[] arg)
	{
		System.out.println("Svaret på livet, universet og alt det der: " + 42);
	}
}