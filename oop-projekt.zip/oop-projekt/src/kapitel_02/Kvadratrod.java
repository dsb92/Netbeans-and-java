package kapitel_02;
public class Kvadratrod
{
	public static void main(String[] arg) 
	{
		System.out.println("kvadratroden af 0 er " + Math.sqrt(0));
		System.out.println("kvadratroden af 1 er " + Math.sqrt(1));
		System.out.println("kvadratroden af 2 er " + Math.sqrt(2));
		System.out.println("kvadratroden af 3 er " + Math.sqrt(3));
		System.out.println("kvadratroden af 4 er " + Math.sqrt(4));
		System.out.println("kvadratroden af 5 er " + Math.sqrt(5));
		System.out.println("kvadratroden af 6 er " + Math.sqrt(6));
		System.out.println("kvadratroden af 7 er " + Math.sqrt(7));
		System.out.println("kvadratroden af 8 er " + Math.sqrt(8));
		System.out.println("kvadratroden af 9 er " + Math.sqrt(9));
		System.out.println("kvadratroden af 10 er " + Math.sqrt(10));
	}
}