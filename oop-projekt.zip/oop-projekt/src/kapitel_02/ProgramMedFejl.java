package kapitel_02;
public class ProgramMedFejl
{
	public static void main (String[] arg)
	{
		System.out.println("Hej Verdne!");
		int sum = 2 - 2;
		System.out.println("2 og 2 er "+sum);
	}
}