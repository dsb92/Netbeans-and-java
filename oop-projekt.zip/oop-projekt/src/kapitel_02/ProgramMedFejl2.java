package kapitel_02;
public class ProgramMedFejl2
{
	public static void main (String[] arg)
	{
		int a,b,c;

		a = 5;
		b = 6;

		c = b/(a-5);
		System.out.println("c = "+c);
	}
}