package kapitel_02;
public class Syvtabel
{
	public static void main(String[] arg) 
	{
		int n;
		n = 1;

		while (n <= 10)
		{
			System.out.println(n+" : "+ 7*n);
			n = n + 1;
		}
	}
}