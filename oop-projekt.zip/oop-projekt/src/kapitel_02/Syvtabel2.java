package kapitel_02;
public class Syvtabel2
{
	public static void main(String[] arg) 
	{
		int n;
		for (n=1; n<=10; n=n+1)
			System.out.println(n+" : "+ 7*n);
	}
}