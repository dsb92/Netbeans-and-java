package kapitel_02;
public class SyvtabelFejl
{
	public static void main(String[] arg) 
	{
		for (int n=1; n<=10; n=n-1)
			System.out.println(n+" : "+ 7*n);
	}
}