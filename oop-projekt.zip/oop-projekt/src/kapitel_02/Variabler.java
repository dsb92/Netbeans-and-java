package kapitel_02;
// Eksempel på brug af en variabel
// koden skal være i filen Variabler.java
public class Variabler
{
	public static void main (String[] arg)
	{
		int tal;
		tal = 22;
		System.out.println("Svaret på livet, universet og alt det der: " + tal);

		tal = 42;
		System.out.println("Undskyld, svaret er: " + tal);
	}
}