package kapitel_08;
public class MaanedersNavne
{
	public static void main(String[] arg) 
	{
		String[] måneder = {"januar", "februar", "marts", "april", "maj", "juni",
		  "juli", "august", "september", "oktober", "november", "december" };

		System.out.println("Den 1. måned er " + måneder[0] );
		System.out.println("Den 6. måned er " + måneder[5] );
		System.out.println("Den 10. måned er " + måneder[9] );	
	}
}