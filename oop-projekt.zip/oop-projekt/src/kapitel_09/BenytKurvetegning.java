package kapitel_09;
public class BenytKurvetegning
{
	public static void main(String[] arg)
	{
		Kurvetegning kt = new Kurvetegning();
	}
}