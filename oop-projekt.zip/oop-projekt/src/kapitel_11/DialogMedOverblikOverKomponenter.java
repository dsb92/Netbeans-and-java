package kapitel_11;
import javax.swing.*;
public class DialogMedOverblikOverKomponenter
{
	public static void main(String[] arg)
	{
		JOptionPane.showMessageDialog(null,new OverblikOverKomponenter());
	}
}