package kapitel_12;
import java.awt.*;

public interface Tegnbar
{
	public void sætPosition(int x, int y);

	public void tegn(Graphics g);
}