package kapitel_12;
public interface Tegnekonstanter
{
	double LæNGDE = 10;
	double BREDDE = 10;
}