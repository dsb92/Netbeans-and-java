package kapitel_13;
import javax.swing.*;
public class BenytAltKapitel13
{
	public static void main(String[] arg)
	{
		JTabbedPane faneblade = new JTabbedPane();
		faneblade.add("1 LytTilMusen", new LytTilMusen());
		faneblade.add("2 Linjetegning", new Linjetegning());
		faneblade.add("3 Linjetegning2", new Linjetegning2());
		faneblade.add("4 Kruseduller", new Kruseduller());
		faneblade.add("5 LytTilKnap", new LytTilKnap());
		faneblade.add("6 Tastetryk", new Tastetryk());
		JFrame vindue = new JFrame("BenytAltKapitel13");
		vindue.add( faneblade );
		vindue.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // reagér på luk
		vindue.pack();                  // lad vinduet selv bestemme sin størrelse
		vindue.setVisible(true);                                  // åbn vinduet
	}
}