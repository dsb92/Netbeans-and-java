package kapitel_14;
import kapitel_05.*;
import java.util.*;

public class SimpelUndtagelse
{
	public static void main(String[] arg)
	{
		System.out.println("Punkt A");       // punkt A
		ArrayList l = new ArrayList();
		System.out.println("Punkt B");       // punkt B
		l.get(5);
		System.out.println("Punkt C");       // punkt C
	}
}